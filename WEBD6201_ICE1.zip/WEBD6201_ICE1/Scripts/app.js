/* 
    Author: Eisha Aqeel (100798173)
    Date: 1/15/2023
    Description: Java Script file for ICE1
*/

//function to display the following alert when the "Click Here" button is clicked
function alertMe(){
    alert("Hello, world!");
}