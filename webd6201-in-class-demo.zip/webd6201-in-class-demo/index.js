//for fun example
const isOdd = require('is-odd')

console.log(isOdd(3))